---
name: best-practices
description: "Best practices for Snowflake development in 4 areas: (1) fast bulk data generation with CTEs instead of INSERTs — use when asked to generate test/fake/sample data, create table with N records, datos ficticios, datos de prueba, synthetic data; (2) AI SQL functions at scale — use when asked to apply CORTEX.COMPLETE, AI_COMPLETE, AI_SENTIMENT, AI_CLASSIFY, AI_SUMMARIZE, AI_TRANSLATE, AI_EXTRACT to many rows, bulk AI processing, LLM over table; (3) Streamlit in Snowflake (SiS) best practices — use when building or debugging a Streamlit app on Snowflake, SiS pitfalls, CSP errors, runtime selection, session management; (4) warehouse scaling for ML — use when running machine learning, ML training, model scoring, ML.CLASSIFY, ML.FORECAST, Snowpark ML, or heavy compute on many rows — scale warehouse to LARGE before executing and back down after. Triggers: datos ficticios, datos de prueba, generar tabla, INSERT lento, GENERATOR, AI function muchas filas, bulk AI, streamlit snowflake, SiS, crear app, machine learning muchas filas, ML training, escalar warehouse, warehouse size, ML.CLASSIFY, ML.FORECAST, Snowpark ML, modelo ML, score model."
---

# Snowflake Dev Patterns

## Intent Detection

| Intent | Triggers | Route |
|--------|----------|-------|
| **Data Generation** | generar tabla, datos ficticios, datos de prueba, synthetic data, sample data, N records, INSERT lento, GENERATOR | Load `references/data-generation.md` |
| **Bulk AI SQL** | AI function muchas filas, CORTEX.COMPLETE tabla, AI_COMPLETE bulk, AI_SENTIMENT, AI_CLASSIFY, AI_SUMMARIZE, AI_TRANSLATE, AI_EXTRACT, LLM over table, apply AI to rows | Load `references/aisql-bulk.md` |
| **Streamlit in Snowflake** | streamlit, SiS, crear app Snowflake, st.connection, get_active_session, CSP error, environment.yml, deploy streamlit | Load `references/streamlit-sis.md` |
| **ML en muchas filas** | machine learning muchas filas, ML training, ML.CLASSIFY, ML.FORECAST, Snowpark ML, modelo ML, score model, escalar warehouse, heavy compute, train model | Load `references/warehouse-scaling.md` |

---

## Workflow

### Step 1: Detect Intent

Match user request to one of the 3 intents above and load the corresponding reference file.

### Step 2: Apply Pattern & Execute Immediately

Follow the loaded reference. Generate the SQL/code adapted to the user's use case and **execute it immediately** — do not show it first and wait for approval.

- **Data generation**: run `CREATE OR REPLACE TABLE ... AS SELECT` via `snowflake_sql_execute`. Then verify row count with `SELECT COUNT(*) FROM <table>`.
- **Bulk AI SQL**: run `CREATE OR REPLACE TABLE ... AS SELECT <AI_FUNCTION>` via `snowflake_sql_execute`. Show sample of results.
- **ML en muchas filas**: follow scaling workflow in `references/warehouse-scaling.md` — scale up → execute ML → scale down. Show row count and restore original size.
- **Streamlit**: write all .py files locally, then follow the full deploy workflow in `references/streamlit-sis.md` (upload to stage → `CREATE OR REPLACE STREAMLIT` → show URL).

## Stopping Points

None — execute all steps automatically without asking for confirmation.

## Output

Executed result: table created with row count, or Streamlit app URL ready to open.
